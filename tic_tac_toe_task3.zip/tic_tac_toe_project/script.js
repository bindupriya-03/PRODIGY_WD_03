const cells = document.querySelectorAll(".cell");
const statusText = document.querySelector(".status");
const restartBtn = document.querySelector(".reset-btn");
const pvpBtn = document.getElementById("pvpBtn");
const aiBtn = document.getElementById("aiBtn");

const popup = document.getElementById("popup");
const popupText = document.querySelector(".popup-text");
const closePopup = document.getElementById("closePopup");

let board = ["", "", "", "", "", "", "", "", ""];
let currentPlayer = "X";
let running = false; 
let mode = null; 

const winPatterns = [
    [0,1,2], [3,4,5], [6,7,8],  
    [0,3,6], [1,4,7], [2,5,8],  
    [0,4,8], [2,4,6]           
];

function startGame(selectedMode) {
    if (selectedMode) {
        mode = selectedMode; 
        running = true;      
        statusText.textContent = "X's Turn";
    } else {
        mode = null;
        running = false;
        statusText.textContent = "Select a mode to start playing!";
    }
    board = ["","","","","","","","",""];
    currentPlayer = "X";

    cells.forEach(cell => {
        cell.textContent = "";
        cell.style.pointerEvents = "auto";
    });

    
    popup.style.display = "none";
}

function cellClicked() {
    const index = this.getAttribute("data-index");
    if (!running || board[index] !== "") return;
    updateCell(this, index);
    checkGameState();
    if (mode === "ai" && running && currentPlayer === "O") {
        setTimeout(aiMove, 400);
    }
}
function updateCell(cell, index) {
    board[index] = currentPlayer;
    cell.textContent = currentPlayer;
    cell.style.pointerEvents = "none";
}
function changePlayer() {
    currentPlayer = currentPlayer === "X" ? "O" : "X";
    statusText.textContent = `${currentPlayer}'s Turn`;
}
function checkWinner() {
    for (let pattern of winPatterns) {
        const [a,b,c] = pattern;
        if (board[a] && board[a] === board[b] && board[a] === board[c]) {
            return board[a]; 
        }
    }
    return null;
}
function checkDraw() {
    return board.every(cell => cell !== "") && !checkWinner();
}
  function checkGameState() {
    const winner = checkWinner();

    if (winner) {
        showPopup(`${winner} Wins! 🏆`);
        running = false;
    } else if (checkDraw()) {
        showPopup("It's a Draw! 🤝");
        running = false;
    } else {
        changePlayer();
    }
}
function aiMove() {

    let best = findBestMove("O");
    if (best !== -1) return makeAIMove(best);

    let block = findBestMove("X");
    if (block !== -1) return makeAIMove(block);

    if (board[4] === "") return makeAIMove(4);

    let available = board.map((v,i)=> v === "" ? i : null).filter(v=>v!==null);
    let randomMove = available[Math.floor(Math.random()*available.length)];
    makeAIMove(randomMove);
}

function makeAIMove(index) {
    const cell = document.querySelector(`[data-index='${index}']`);
    updateCell(cell, index);
    checkGameState();
}
function findBestMove(player) {
    for (let pattern of winPatterns) {
        const [a,b,c] = pattern;

        if (board[a] === player && board[b] === player && board[c] === "") return c;
        if (board[a] === player && board[b] === "" && board[c] === player) return b;
        if (board[a] === "" && board[b] === player && board[c] === player) return a;
    }
    return -1;
}
function showPopup(message) {
    running = false;
    popupText.textContent = message;
    popup.style.display = "flex";
}
closePopup.addEventListener("click", () => {
    popup.style.display = "none";
    startGame(); 
});
restartBtn.addEventListener("click", () => startGame()); 
pvpBtn.addEventListener("click", () => startGame("pvp"));
aiBtn.addEventListener("click", () => startGame("ai"));
cells.forEach(cell => {
    cell.addEventListener("click", cellClicked);
});

startGame(); 
